/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Double Ratchet Comprehensive Test Suite
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Tests cover:
 *   1. Basic initialization (Alice & Bob roles)
 *   2. End-to-end message exchange
 *   3. Symmetric ratchet (sequential message keys differ)
 *   4. DH ratchet triggers on first response
 *   5. Out-of-order message delivery (up to 1000)
 *   6. Anti-replay protection
 *   7. Root key rotation
 *   8. IndexedDB persistence (save/load roundtrip)
 *   9. Session destruction and key wipe
 *   10. Tampering detection
 *   11. Multiparty/multisession isolation
 *
 * Run in browser console or Node 20+ with --experimental-vm-modules
 * ═══════════════════════════════════════════════════════════════════════════════
 */

const { DoubleRatchet, generateEphemeralKeyPair, exportPublicKeyRawB64, deriveInitialRootKey, computeSafetyNumber } =
  typeof module !== 'undefined' ? require('./doubleRatchet.js') : window;

// ═════════════════════════════════════════════════════════════════════════════
//  TEST FRAMEWORK (minimal, zero-dependency)
// ═════════════════════════════════════════════════════════════════════════════

let passed = 0;
let failed = 0;

async function test(name, fn) {
  try {
    await fn();
    console.log(`  PASS: ${name}`);
    passed++;
  } catch (e) {
    console.error(`  FAIL: ${name}\n    → ${e.message}`);
    failed++;
  }
}

function assertEq(actual, expected, msg) {
  if (actual !== expected) {
    throw new Error(`${msg || 'Assertion failed'}: expected ${expected}, got ${actual}`);
  }
}

function assertTrue(cond, msg) {
  if (!cond) throw new Error(msg || 'Expected true');
}

function assertBufEq(a, b, msg) {
  if (a.byteLength !== b.byteLength) throw new Error(`${msg}: length mismatch`);
  const ua = new Uint8Array(a);
  const ub = new Uint8Array(b);
  for (let i = 0; i < ua.length; i++) {
    if (ua[i] !== ub[i]) throw new Error(`${msg}: byte mismatch at ${i}`);
  }
}

// ═════════════════════════════════════════════════════════════════════════════
//  TEST HELPERS
// ═════════════════════════════════════════════════════════════════════════════

/** Simulate an X3DH key agreement to produce a shared root key */
async function simulateX3DH() {
  const bobPair = await generateEphemeralKeyPair();
  const bobPubRaw = await exportPublicKeyRawB64(bobPair.publicKey);

  // Alice generates ephemeral key and derives shared secret
  const aliceEphemeral = await generateEphemeralKeyPair();
  const sharedSecret = await crypto.subtle.deriveBits(
    { name: 'ECDH', public: bobPair.publicKey },
    aliceEphemeral.privateKey,
    256
  );

  const rootKey = await deriveInitialRootKey(sharedSecret);
  const rootKeyB64 = btoa(String.fromCharCode(...new Uint8Array(rootKey)));

  return { rootKeyB64, bobPubRaw, bobPair };
}

// ═════════════════════════════════════════════════════════════════════════════
//  TEST SUITE
// ═════════════════════════════════════════════════════════════════════════════

async function runAllTests() {
  console.log('\n═══════════════════════════════════════════════════════════');
  console.log('  Signal Double Ratchet — Test Suite');
  console.log('═══════════════════════════════════════════════════════════\n');

  // ── TEST 1: Initialization ────────────────────────────────
  await test('initAlice sets state correctly', async () => {
    const { rootKeyB64, bobPubRaw } = await simulateX3DH();
    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    assertTrue(alice.isReady(), 'Alice should be ready');
    assertTrue(await alice.getDHPublicKey() !== bobPubRaw, 'Alice should have her own key');
  });

  await test('initBob sets state correctly', async () => {
    const { rootKeyB64, bobPair } = await simulateX3DH();
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);
    assertTrue(bob.isReady(), 'Bob should be ready');
  });

  await test('uninitialized session rejects operations', async () => {
    const dr = new DoubleRatchet();
    let threw = false;
    try { await dr.encrypt('test'); } catch { threw = true; }
    assertTrue(threw, 'Should throw when not initialized');
  });

  // ── TEST 2: Basic end-to-end exchange ─────────────────────
  await test('Alice → Bob message decrypts correctly', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);

    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    const msg = 'Hello Bob! This is Alice.';
    const enc = await alice.encrypt(msg);
    const dec = await bob.decryptString(enc.header, enc.ciphertext);
    assertEq(dec, msg, 'Decrypted should match original');
  });

  await test('Bob → Alice reply decrypts correctly', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);

    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    // Alice sends first
    const enc1 = await alice.encrypt('First message');
    await bob.decrypt(enc1.header, enc1.ciphertext);

    // Bob replies
    const reply = 'Got it, Alice!';
    const enc2 = await bob.encrypt(reply);
    const dec2 = await alice.decryptString(enc2.header, enc2.ciphertext);
    assertEq(dec2, reply, 'Reply should decrypt');
  });

  // ── TEST 3: Symmetric ratchet (sequential keys differ) ────
  await test('sequential messages use different keys', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);

    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    const ct1 = await alice.encrypt('Message 1');
    const ct2 = await alice.encrypt('Message 2');

    // Ciphertexts should differ (different IVs + different message keys)
    assertTrue(ct1.ciphertext !== ct2.ciphertext, 'Ciphertexts should differ');
    assertTrue(ct1.header.n === 0, 'First message n=0');
    assertTrue(ct2.header.n === 1, 'Second message n=1');

    // Both decrypt
    const d1 = await bob.decryptString(ct1.header, ct1.ciphertext);
    const d2 = await bob.decryptString(ct2.header, ct2.ciphertext);
    assertEq(d1, 'Message 1');
    assertEq(d2, 'Message 2');
  });

  // ── TEST 4: DH ratchet ────────────────────────────────────
  await test('DH ratchet triggers on first reply', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);

    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    // Alice sends → Bob receives (this triggers Bob's first DH ratchet on reply)
    const a2b = await alice.encrypt('Ping');
    await bob.decrypt(a2b.header, a2b.ciphertext);

    // Bob sends → Alice receives (this triggers Alice's DH ratchet)
    const b2a_1 = await bob.encrypt('Pong 1');
    await alice.decrypt(b2a_1.header, b2a_1.ciphertext);

    // Alice sends again (should work with new chain)
    const a2b_2 = await alice.encrypt('Ping 2');
    const dec = await bob.decryptString(a2b_2.header, a2b_2.ciphertext);
    assertEq(dec, 'Ping 2');
  });

  await test('multi-round conversation with ratcheting', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    const messages = [
      { sender: 'a', text: 'Hey Bob!' },
      { sender: 'b', text: 'Hey Alice!' },
      { sender: 'a', text: 'How are you?' },
      { sender: 'b', text: 'Doing great!' },
      { sender: 'b', text: 'You?' },
      { sender: 'a', text: 'Same here' },
      { sender: 'b', text: 'Good to hear' },
    ];

    const encrypted = [];
    for (const m of messages) {
      if (m.sender === 'a') {
        encrypted.push(await alice.encrypt(m.text));
      } else {
        encrypted.push(await bob.encrypt(m.text));
      }
    }

    // Decrypt all in order
    const aliceDec = new DoubleRatchet();
    await aliceDec.initAlice(rootKeyB64, bobPubRaw);
    const bobDec = new DoubleRatchet();
    await bobDec.initBob(rootKeyB64, bobPair);

    for (let i = 0; i < messages.length; i++) {
      const m = messages[i];
      const e = encrypted[i];
      const dec = m.sender === 'a'
        ? await bobDec.decryptString(e.header, e.ciphertext)
        : await aliceDec.decryptString(e.header, e.ciphertext);
      assertEq(dec, m.text, `Message ${i} should match`);
    }
  });

  // ── TEST 5: Out-of-order messages ─────────────────────────
  await test('single out-of-order message', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    const m1 = await alice.encrypt('First');
    const m2 = await alice.encrypt('Second');
    const m3 = await alice.encrypt('Third');

    // Decrypt out of order: 2, 3, 1
    const d2 = await bob.decryptString(m2.header, m2.ciphertext);
    const d3 = await bob.decryptString(m3.header, m3.ciphertext);
    const d1 = await bob.decryptString(m1.header, m1.ciphertext);

    assertEq(d2, 'Second');
    assertEq(d3, 'Third');
    assertEq(d1, 'First');
  });

  await test('multiple out-of-order messages', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    // Alice sends 10 messages
    const msgs = [];
    for (let i = 0; i < 10; i++) {
      msgs.push(await alice.encrypt(`msg-${i}`));
    }

    // Bob receives in reverse order
    for (let i = 9; i >= 0; i--) {
      const dec = await bob.decryptString(msgs[i].header, msgs[i].ciphertext);
      assertEq(dec, `msg-${i}`);
    }
  });

  await test('out-of-order after DH ratchet', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    // Exchange to trigger DH ratchet
    const e1 = await alice.encrypt('Alice 1');
    const e2 = await alice.encrypt('Alice 2');
    await bob.decrypt(e1.header, e1.ciphertext);
    const r1 = await bob.encrypt('Bob reply');
    await alice.decrypt(r1.header, r1.ciphertext);

    // Alice sends more
    const e3 = await alice.encrypt('Alice 3');
    const e4 = await alice.encrypt('Alice 4');
    const e5 = await alice.encrypt('Alice 5');

    // Bob receives out of order
    const d4 = await bob.decryptString(e4.header, e4.ciphertext);
    const d5 = await bob.decryptString(e5.header, e5.ciphertext);
    const d3 = await bob.decryptString(e3.header, e3.ciphertext);

    assertEq(d3, 'Alice 3');
    assertEq(d4, 'Alice 4');
    assertEq(d5, 'Alice 5');
  });

  await test('skip limit enforced', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet({ maxSkip: 5 });
    await bob.initBob(rootKeyB64, bobPair);

    // Alice sends 10 messages
    const msgs = [];
    for (let i = 0; i < 10; i++) {
      msgs.push(await alice.encrypt(`msg-${i}`));
    }

    // Bob tries to decrypt msg 9 first (would need to skip 9 > 5)
    let threw = false;
    try {
      await bob.decrypt(msgs[9].header, msgs[9].ciphertext);
    } catch (e) {
      if (e.message.includes('Skip limit exceeded')) threw = true;
    }
    assertTrue(threw, 'Should throw when skip limit exceeded');
  });

  // ── TEST 6: Associated data ───────────────────────────────
  await test('associated data authentication', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    const ad = new Uint8Array([1, 2, 3, 4, 5]);
    const enc = await alice.encrypt('Secret with AD', ad);

    // Correct AD
    const dec = await bob.decrypt(enc.header, enc.ciphertext, ad);
    assertEq(new TextDecoder().decode(dec), 'Secret with AD');

    // Wrong AD should fail
    let threw = false;
    const bob2 = new DoubleRatchet();
    await bob2.initBob(rootKeyB64, bobPair);
    try {
      await bob2.decrypt(enc.header, enc.ciphertext, new Uint8Array([5, 4, 3, 2, 1]));
    } catch {
      threw = true;
    }
    assertTrue(threw, 'Wrong AD should cause auth failure');
  });

  // ── TEST 7: Tampering detection ───────────────────────────
  await test('tampered ciphertext is rejected', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    const enc = await alice.encrypt('Untampered');

    // Tamper: flip a bit in the ciphertext
    const ctBytes = Uint8Array.from(atob(enc.ciphertext), c => c.charCodeAt(0));
    ctBytes[15] ^= 0xFF;
    const tamperedCiphertext = btoa(String.fromCharCode(...ctBytes));

    let threw = false;
    try {
      await bob.decrypt(enc.header, tamperedCiphertext);
    } catch {
      threw = true;
    }
    assertTrue(threw, 'Tampered ciphertext should be rejected');
  });

  await test('tampered header is rejected', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    const enc = await alice.encrypt('Header test');

    // Tamper with header message number
    const badHeader = { ...enc.header, n: enc.header.n + 1 };

    let threw = false;
    try {
      await bob.decrypt(badHeader, enc.ciphertext);
    } catch {
      threw = true;
    }
    assertTrue(threw, 'Tampered header should cause failure');
  });

  // ── TEST 8: Anti-replay / duplicate handling ──────────────
  await test('consumed skipped key cannot be replayed', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    const m1 = await alice.encrypt('First');
    const m2 = await alice.encrypt('Second');

    // Bob decrypts m2 first (m1 skipped)
    await bob.decrypt(m2.header, m2.ciphertext);

    // Now try to replay m2
    let threw = false;
    const bob2 = new DoubleRatchet();
    await bob2.initBob(rootKeyB64, bobPair);
    // Bob2 doesn't know m1 was skipped, but even if it did:
    // The key for m2 would be consumed

    // A proper replay test: the same key should not decrypt twice
    // Since m2's key was consumed in bob, a fresh bob2 should have it in skipped
    // But after first decrypt, it's gone
    await bob2.decrypt(m2.header, m2.ciphertext); // First time OK
    let replayFailed = false;
    try {
      await bob2.decrypt(m2.header, m2.ciphertext); // Second time should fail
    } catch {
      replayFailed = true;
    }
    assertTrue(replayFailed, 'Replay should fail');
  });

  // ── TEST 9: Root key rotation ─────────────────────────────
  await test('root key rotation triggers periodically', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet({ rotationPeriod: 3 });
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet({ rotationPeriod: 3 });
    await bob.initBob(rootKeyB64, bobPair);

    // Exchange to establish chains
    const e1 = await alice.encrypt('init');
    await bob.decrypt(e1.header, e1.ciphertext);
    const r1 = await bob.encrypt('reply');
    await alice.decrypt(r1.header, r1.ciphertext);

    // Alice sends 5 messages - rotation should trigger at message 3
    for (let i = 0; i < 5; i++) {
      const enc = await alice.encrypt(`msg-${i}`);
      const dec = await bob.decryptString(enc.header, enc.ciphertext);
      assertEq(dec, `msg-${i}`);
    }
  });

  // ── TEST 10: Persistence (IndexedDB) ──────────────────────
  await test('save and load roundtrip preserves state', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet({
      sessionId: 'test-alice',
      passphrase: 'test-pass-123'
    });
    await alice.initAlice(rootKeyB64, bobPubRaw);

    // Send some messages
    const e1 = await alice.encrypt('Before save');

    // Save state
    await alice.save();

    // Create new instance and load
    const alice2 = new DoubleRatchet({
      sessionId: 'test-alice',
      passphrase: 'test-pass-123'
    });
    const loaded = await alice2.load();
    assertTrue(loaded, 'Should load successfully');

    // Can continue encrypting
    const e2 = await alice2.encrypt('After load');

    // Bob should decrypt both
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);
    const d1 = await bob.decryptString(e1.header, e1.ciphertext);
    const d2 = await bob.decryptString(e2.header, e2.ciphertext);
    assertEq(d1, 'Before save');
    assertEq(d2, 'After load');
  });

  // ── TEST 11: Session destruction ──────────────────────────
  await test('destroy wipes all key material', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    alice.destroy();

    let threw = false;
    try { await alice.encrypt('should fail'); } catch { threw = true; }
    assertTrue(threw, 'Should not work after destroy');
    assertTrue(!alice.isReady(), 'Should not be ready after destroy');
  });

  // ── TEST 12: Multiparty isolation ─────────────────────────
  await test('separate sessions are cryptographically isolated', async () => {
    const { rootKeyB64: rk1, bobPubRaw: bp1, bobPair: bkp1 } = await simulateX3DH();

    // Alice talks to Bob1
    const alice1 = new DoubleRatchet();
    await alice1.initAlice(rk1, bp1);
    const bob1 = new DoubleRatchet();
    await bob1.initBob(rk1, bkp1);

    // Simulate different shared secret with Bob2
    const bkp2 = await generateEphemeralKeyPair();
    const bp2 = await exportPublicKeyRawB64(bkp2.publicKey);
    const aliceEphemeral2 = await generateEphemeralKeyPair();
    const ss2 = await crypto.subtle.deriveBits(
      { name: 'ECDH', public: bkp2.publicKey },
      aliceEphemeral2.privateKey,
      256
    );
    const rk2 = btoa(String.fromCharCode(...new Uint8Array(await deriveInitialRootKey(ss2))));

    const alice2 = new DoubleRatchet();
    await alice2.initAlice(rk2, bp2);
    const bob2 = new DoubleRatchet();
    await bob2.initBob(rk2, bkp2);

    // Encrypt same message to both
    const enc1 = await alice1.encrypt('Secret');
    const enc2 = await alice2.encrypt('Secret');

    // Ciphertexts should be completely different
    assertTrue(enc1.ciphertext !== enc2.ciphertext, 'Same plaintext → different ciphertext');

    // Cross-decrypt should fail
    let crossFailed = false;
    try {
      await bob2.decrypt(enc1.header, enc1.ciphertext);
    } catch { crossFailed = true; }
    assertTrue(crossFailed, 'Cross-session decrypt should fail');
  });

  // ── TEST 13: Stats and monitoring ─────────────────────────
  await test('getStats returns accurate counters', async () => {
    const { rootKeyB64, bobPubRaw, bobPair } = await simulateX3DH();

    const alice = new DoubleRatchet();
    await alice.initAlice(rootKeyB64, bobPubRaw);
    const bob = new DoubleRatchet();
    await bob.initBob(rootKeyB64, bobPair);

    const s1 = alice.getStats();
    assertEq(s1.ns, 0, 'Initial Ns=0');
    assertEq(s1.nr, 0, 'Initial Nr=0');

    const enc = await alice.encrypt('test');
    const s2 = alice.getStats();
    assertEq(s2.ns, 1, 'Ns=1 after one encrypt');

    await bob.decrypt(enc.header, enc.ciphertext);
    const s3 = bob.getStats();
    assertEq(s3.nr, 1, 'Bob Nr=1 after decrypt');
  });

  // ── TEST 14: Safety numbers ───────────────────────────────
  await test('safety numbers are deterministic and symmetric', async () => {
    const kp1 = await generateEphemeralKeyPair();
    const kp2 = await generateEphemeralKeyPair();
    const pub1 = await exportPublicKeyRawB64(kp1.publicKey);
    const pub2 = await exportPublicKeyRawB64(kp2.publicKey);

    const sn1 = await computeSafetyNumber(pub1, pub2);
    const sn2 = await computeSafetyNumber(pub2, pub1);

    assertEq(sn1, sn2, 'Safety number should be symmetric');
    assertEq(sn1.length, 71, '60 digits + 11 spaces = 71 chars');
    assertTrue(/\d{5}/.test(sn1), 'Should contain 5-digit groups');
  });

  // ════════════════════════════════════════════════════════════
  //  SUMMARY
  // ════════════════════════════════════════════════════════════

  console.log('\n═══════════════════════════════════════════════════════════');
  console.log(`  Results: ${passed} passed, ${failed} failed`);
  console.log('═══════════════════════════════════════════════════════════');

  if (typeof window !== 'undefined') {
    window.__testResults = { passed, failed };
  }
  if (typeof module !== 'undefined') {
    module.exports = { passed, failed };
  }

  return { passed, failed };
}

// Auto-run if in browser
if (typeof window !== 'undefined') {
  runAllTests();
}

// Export for Node
if (typeof module !== 'undefined') {
  module.exports = { runAllTests };
}
