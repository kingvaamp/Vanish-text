/**
 * Validation test runner for DoubleRatchet implementation
 */
const crypto = require("crypto").webcrypto;
global.crypto = crypto;

let passed = 0, failed = 0;
async function test(name, fn) {
  try { await fn(); passed++; console.log("\u2713 " + name); }
  catch(e) { failed++; console.error("\u2717 " + name + "\n  \u2192 " + e.message); }
}
function assertEq(a, e, m) { if (a !== e) throw new Error((m||"eq") + ": got "+a+" exp "+e); }
function assertT(c, m) { if (!c) throw new Error(m || "true"); }

// ── Constants ──
const ALG_AES = 'AES-GCM';
const ALG_ECDH = { name: 'ECDH', namedCurve: 'P-256' };
const RK_BYTES = 32, CK_BYTES = 32, MK_BYTES = 32;
const AES_IV_BYTES = 12;
const ENC = new TextEncoder();
const DEC = new TextDecoder();

function b64e(b) { return Buffer.from(b).toString("base64"); }
function b64d(s) { return new Uint8Array(Buffer.from(s, "base64")); }
function concat(...b) {
  const t = b.reduce((s,x)=>s+x.byteLength,0);
  const o=new Uint8Array(t); let off=0;
  for(const x of b){o.set(new Uint8Array(x),off);off+=x.byteLength;}
  return o;
}

// ── Crypto primitives ──
async function genDH() { return crypto.subtle.generateKey(ALG_ECDH, true, ['deriveBits']); }
async function dh(priv, pub) { return crypto.subtle.deriveBits({name:'ECDH',public:pub}, priv, 256); }
async function hkdf(salt, ikm, info, len) {
  const key = await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']);
  return crypto.subtle.deriveBits(
    {name:'HKDF',hash:'SHA-256',salt:salt||new Uint8Array(32),info:ENC.encode(info)},
    key, len*8
  );
}
async function kdfRK(rk, dhOut) {
  const out = await hkdf(rk, dhOut, 'DoubleRatchetKeys', RK_BYTES+CK_BYTES);
  return [out.slice(0,RK_BYTES), out.slice(RK_BYTES,RK_BYTES+CK_BYTES)];
}
async function kdfCK(ck) {
  const out = await hkdf(null, ck, 'DoubleRatchetChainKeys', CK_BYTES+MK_BYTES);
  return [out.slice(0,CK_BYTES), out.slice(CK_BYTES,CK_BYTES+MK_BYTES)];
}
async function aesGcmEnc(key, pt, ad) {
  const iv = crypto.getRandomValues(new Uint8Array(AES_IV_BYTES));
  const k = await crypto.subtle.importKey('raw', key, ALG_AES, false, ['encrypt']);
  const ct = await crypto.subtle.encrypt({name:ALG_AES,iv,tagLength:128,additionalData:ad}, k, pt);
  return {iv, ciphertext:ct};
}
async function aesGcmDec(key, iv, ct, ad) {
  const k = await crypto.subtle.importKey('raw', key, ALG_AES, false, ['decrypt']);
  return crypto.subtle.decrypt({name:ALG_AES,iv,tagLength:128,additionalData:ad}, k, ct);
}
function headerToBytes(h) {
  const dhPub = b64d(h.dh);
  const buf = new Uint8Array(dhPub.length+8);
  buf.set(dhPub,0);
  const v = new DataView(buf.buffer, dhPub.length, 8);
  v.setUint32(0, h.n, false); v.setUint32(4, h.pn, false);
  return buf;
}
async function impDHPub(raw) { return crypto.subtle.importKey('raw', raw, ALG_ECDH, true, []); }
async function eqCK(a,b) {
  const ra=await crypto.subtle.exportKey('raw',a);
  const rb=await crypto.subtle.exportKey('raw',b);
  return Buffer.from(ra).equals(Buffer.from(rb));
}

// ── DoubleRatchet (validated implementation) ──
class DoubleRatchet {
  constructor(opts={}) {
    this.maxSkip = opts.maxSkip??1000;
    this.maxKeep = opts.maxKeep??1000;
    this.rotPeriod = opts.rotationPeriod??500;
    this.sessionId = opts.sessionId;
    this.RK=this.CKs=this.CKr=this.DHs=this.DHr=this.DHrRaw=null;
    this.Ns=this.Nr=this.PN=0;
    this.MKSKIPPED=new Map();
    this.msgSinceRot=0;
    this.init=false;
    this.store = this.sessionId ? { data:new Map(), async save(sid,state){this.data.set(sid,JSON.parse(JSON.stringify(state)));}, async load(sid){return this.data.get(sid)||null;} } : null;
  }
  assertReady() { if(!this.init) throw new Error('not init'); }

  async initAlice(rk, bobPub) {
    this.RK = b64d(rk).slice(0,32).buffer;
    this.DHr = await impDHPub(b64d(bobPub));
    this.DHrRaw = bobPub;
    this.DHs = await genDH();
    this.CKs=this.CKr=null;
    this.Ns=this.Nr=this.PN=0;
    this.MKSKIPPED=new Map();
    this.msgSinceRot=0;
    this.init=true;
  }
  async initBob(rk, bobKP) {
    this.RK = b64d(rk).slice(0,32).buffer;
    this.DHs = bobKP;
    this.DHr=this.DHrRaw=null;
    this.CKs=this.CKr=null;
    this.Ns=this.Nr=this.PN=0;
    this.MKSKIPPED=new Map();
    this.msgSinceRot=0;
    this.init=true;
  }

  async SkipMessageKeys(until) {
    if(!this.CKr) return;
    if(this.Nr>=until) return;
    if(until-this.Nr>this.maxSkip) throw new Error('skip limit exceeded: '+ (until-this.Nr));
    while(this.Nr<until) {
      const [nck,mk]=await kdfCK(this.CKr);
      this.CKr=nck;
      this.MKSKIPPED.set(`${this.DHrRaw}|${this.Nr}`,mk);
      this.Nr++;
    }
  }

  async TrySkippedMessageKeys(hdr, ctB64, ad) {
    const mk=this.MKSKIPPED.get(`${hdr.dh}|${hdr.n}`);
    if(!mk) return null;
    try {
      const c=b64d(ctB64); const iv=c.slice(0,12); const ct=c.slice(12);
      const pt=await aesGcmDec(mk,iv,ct,ad);
      this.MKSKIPPED.delete(`${hdr.dh}|${hdr.n}`);
      return pt;
    } catch { return null; }
  }

  async DHRatchet(hdr) {
    await this.SkipMessageKeys(hdr.pn);
    const dhPub=await impDHPub(b64d(hdr.dh));
    this.PN=this.Ns; this.Ns=0; this.Nr=0;
    this.DHr=dhPub; this.DHrRaw=hdr.dh;
    const dhOut1=await dh(this.DHs.privateKey,this.DHr);
    const [rk1,ckr]=await kdfRK(this.RK,dhOut1);
    this.RK=rk1; this.CKr=ckr;
    const newDHs=await genDH(); this.DHs=newDHs;
    const dhOut2=await dh(newDHs.privateKey,this.DHr);
    const [rk2,cks]=await kdfRK(this.RK,dhOut2);
    this.RK=rk2; this.CKs=cks;
  }

  async encrypt(pt, ad) {
    this.assertReady();
    const adBuf = !ad?new ArrayBuffer(0):(typeof ad==='string'?ENC.encode(ad):ad);
    if(!this.CKs && this.DHr && this.RK) {
      const dhOut=await dh(this.DHs.privateKey,this.DHr);
      const [rk,cks]=await kdfRK(this.RK,dhOut); this.RK=rk; this.CKs=cks;
    }
    if(!this.CKs) throw new Error('no CKs');
    const [nck,mk]=await kdfCK(this.CKs); this.CKs=nck;
    this.msgSinceRot++;
    const pubRaw=await crypto.subtle.exportKey('raw',this.DHs.publicKey);
    const hdr={dh:b64e(pubRaw),n:this.Ns,pn:this.PN}; this.Ns++;
    const hb=headerToBytes(hdr);
    const fullAD=concat(adBuf,hb);
    const p=typeof pt==='string'?ENC.encode(pt):pt;
    const {iv,ciphertext}=await aesGcmEnc(mk,p,fullAD);
    return {hdr,ciphertext:b64e(concat(iv,ciphertext))};
  }

  async decrypt(hdr, ctB64, ad) {
    this.assertReady();
    const adBuf=!ad?new ArrayBuffer(0):(typeof ad==='string'?ENC.encode(ad):ad);
    const hb=headerToBytes(hdr);
    const fullAD=concat(adBuf,hb);
    const skipped=await this.TrySkippedMessageKeys(hdr,ctB64,fullAD);
    if(skipped) return new Uint8Array(skipped);
    const dhPub=await impDHPub(b64d(hdr.dh));
    if(!this.DHr || !(await eqCK(this.DHr,dhPub))) await this.DHRatchet(hdr);
    await this.SkipMessageKeys(hdr.n);
    if(!this.CKr) throw new Error('no CKr');
    const [nck,mk]=await kdfCK(this.CKr); this.CKr=nck; this.Nr++;
    const c=b64d(ctB64); const iv=c.slice(0,12); const ct=c.slice(12);
    const plaintext=await aesGcmDec(mk,iv,ct,fullAD);
    return new Uint8Array(plaintext);
  }

  async decryptString(h,c,a) { const b=await this.decrypt(h,c,a); return DEC.decode(b); }
}

// ── Helpers ──
async function simX3DH() {
  const bobPair=await genDH();
  const bobPubRaw=await crypto.subtle.exportKey('raw',bobPair.publicKey);
  const aliceEp=await genDH();
  const ss=await crypto.subtle.deriveBits({name:'ECDH',public:bobPair.publicKey},aliceEp.privateKey,256);
  const rk=await hkdf(null, ss, 'VanishDoubleRatchetRootKey', 32);
  return { rootKey: b64e(rk), bobPub: b64e(bobPubRaw), bobPair };
}

// ═══════════════════════════════════════════
//  TEST SUITE
// ═══════════════════════════════════════════
async function runTests() {
console.log("Running Double Ratchet validation tests...\n");

await test('initAlice', async () => {
  const {rootKey,bobPub}=await simX3DH();
  const dr=new DoubleRatchet();
  await dr.initAlice(rootKey,bobPub);
  assertT(dr.init, 'ready');
});

await test('initBob', async () => {
  const {rootKey,bobPair}=await simX3DH();
  const dr=new DoubleRatchet();
  await dr.initBob(rootKey,bobPair);
  assertT(dr.init, 'ready');
});

await test('Alice\u2192Bob encrypt/decrypt', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const enc=await a.encrypt('Hello Bob!');
  const dec=await b.decryptString(enc.hdr, enc.ciphertext);
  assertEq(dec, 'Hello Bob!', 'decrypt');
});

await test('Bob\u2192Alice reply', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const e1=await a.encrypt('Ping');
  await b.decryptString(e1.hdr,e1.ciphertext);
  const r1=await b.encrypt('Pong');
  assertEq(await a.decryptString(r1.hdr, r1.ciphertext), 'Pong');
});

await test('Sequential messages differ', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const e1=await a.encrypt('M1'); const e2=await a.encrypt('M2');
  assertT(e1.ciphertext!==e2.ciphertext, 'ct differs');
  assertEq(await b.decryptString(e1.hdr,e1.ciphertext), 'M1');
  assertEq(await b.decryptString(e2.hdr,e2.ciphertext), 'M2');
});

await test('DH ratchet on reply', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const e1=await a.encrypt('A1'); await b.decryptString(e1.hdr,e1.ciphertext);
  const r1=await b.encrypt('B1'); await a.decryptString(r1.hdr,r1.ciphertext);
  const e2=await a.encrypt('A2');
  assertEq(await b.decryptString(e2.hdr,e2.ciphertext), 'A2');
});

await test('Multi-round conversation (7 messages)', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  // A1: Alice sends, Bob receives
  const e1=await a.encrypt('A1');
  assertEq(await b.decryptString(e1.hdr,e1.ciphertext), 'A1');
  // B1: Bob sends, Alice receives
  const e2=await b.encrypt('B1');
  assertEq(await a.decryptString(e2.hdr,e2.ciphertext), 'B1');
  // A2: Alice sends, Bob receives
  const e3=await a.encrypt('A2');
  assertEq(await b.decryptString(e3.hdr,e3.ciphertext), 'A2');
  // B2: Bob sends, Alice receives
  const e4=await b.encrypt('B2');
  assertEq(await a.decryptString(e4.hdr,e4.ciphertext), 'B2');
  // A3: Alice sends, Bob receives
  const e5=await a.encrypt('A3');
  assertEq(await b.decryptString(e5.hdr,e5.ciphertext), 'A3');
  // B3: Bob sends, Alice receives
  const e6=await b.encrypt('B3');
  assertEq(await a.decryptString(e6.hdr,e6.ciphertext), 'B3');
  // A4: Alice sends, Bob receives
  const e7=await a.encrypt('A4');
  assertEq(await b.decryptString(e7.hdr,e7.ciphertext), 'A4');
});

await test('Out-of-order single message', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const m1=await a.encrypt('1st'); const m2=await a.encrypt('2nd'); const m3=await a.encrypt('3rd');
  assertEq(await b.decryptString(m2.hdr,m2.ciphertext), '2nd');
  assertEq(await b.decryptString(m3.hdr,m3.ciphertext), '3rd');
  assertEq(await b.decryptString(m1.hdr,m1.ciphertext), '1st');
});

await test('Out-of-order reverse (10 msgs)', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const msgs=[]; for(let i=0;i<10;i++) msgs.push(await a.encrypt(`m${i}`));
  for(let i=9;i>=0;i--) assertEq(await b.decryptString(msgs[i].hdr,msgs[i].ciphertext), `m${i}`);
});

await test('Out-of-order after DH ratchet', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const e0=await a.encrypt('x'); await b.decryptString(e0.hdr,e0.ciphertext);
  const r=await b.encrypt('y'); await a.decryptString(r.hdr,r.ciphertext);
  const e3=await a.encrypt('3'); const e4=await a.encrypt('4'); const e5=await a.encrypt('5');
  assertEq(await b.decryptString(e4.hdr,e4.ciphertext),'4');
  assertEq(await b.decryptString(e5.hdr,e5.ciphertext),'5');
  assertEq(await b.decryptString(e3.hdr,e3.ciphertext),'3');
});

await test('Skip limit enforced', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet({maxSkip:3}); await b.initBob(rootKey,bobPair);
  const msgs=[]; for(let i=0;i<8;i++) msgs.push(await a.encrypt(`m${i}`));
  let threw=false;
  try{await b.decrypt(msgs[7].hdr,msgs[7].ciphertext);}catch(e){if(e.message.includes('limit'))threw=true;}
  assertT(threw,'skip limit');
});

await test('Associated data auth', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const ad=new Uint8Array([1,2,3,4,5]);
  const e=await a.encrypt('secret',ad);
  assertEq(await b.decryptString(e.hdr,e.ciphertext,ad),'secret');
});

await test('Tampered ciphertext rejected', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const e=await a.encrypt('ok');
  const c=b64d(e.ciphertext); c[15]^=0xFF;
  let threw=false; try{await b.decrypt(e.hdr,b64e(c));}catch{threw=true;}
  assertT(threw,'tamper reject');
});

await test('Tampered header rejected', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const e=await a.encrypt('test');
  const bad={...e.hdr,n:e.hdr.n+1};
  let threw=false; try{await b.decrypt(bad,e.ciphertext);}catch{threw=true;}
  assertT(threw,'header tamper');
});

await test('Anti-replay: consumed key cannot replay', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const m1=await a.encrypt('A'); const m2=await a.encrypt('B');
  await b.decryptString(m2.hdr,m2.ciphertext);
  const b2=new DoubleRatchet(); await b2.initBob(rootKey,bobPair);
  await b2.decryptString(m2.hdr,m2.ciphertext);
  let replay=false; try{await b2.decryptString(m2.hdr,m2.ciphertext);}catch{replay=true;}
  assertT(replay,'replay blocked');
});

await test('Safety numbers deterministic', async () => {
  const kp1=await genDH(); const kp2=await genDH();
  const p1=b64e(await crypto.subtle.exportKey('raw',kp1.publicKey));
  const p2=b64e(await crypto.subtle.exportKey('raw',kp2.publicKey));
  const sorted=[p1,p2].sort();
  const hash1=await crypto.subtle.digest('SHA-256',ENC.encode(sorted.join('||VanishText||')));
  const hash2=await crypto.subtle.digest('SHA-256',ENC.encode(sorted.join('||VanishText||')));
  assertT(Buffer.from(hash1).equals(Buffer.from(hash2)),'symmetric');
});

await test('Session stats accurate', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  assertEq(a.Ns,0,'init ns'); assertEq(b.Nr,0,'init nr');
  const e1=await a.encrypt('t1');
  assertEq(a.Ns,1,'ns after 1st enc');
  const e2=await a.encrypt('t2');
  assertEq(a.Ns,2,'ns after 2nd enc');
  // Decrypt in order: Nr goes 0 -> 1
  await b.decrypt(e1.hdr,e1.ciphertext);
  assertEq(b.Nr,1,'nr after 1st dec (in order)');
  await b.decrypt(e2.hdr,e2.ciphertext);
  assertEq(b.Nr,2,'nr after 2nd dec (in order)');
});

await test('Binary plaintext', async () => {
  const {rootKey,bobPub,bobPair}=await simX3DH();
  const a=new DoubleRatchet(); await a.initAlice(rootKey,bobPub);
  const b=new DoubleRatchet(); await b.initBob(rootKey,bobPair);
  const bin=new Uint8Array([0,1,2,255,254,253,128,64,32]);
  const e=await a.encrypt(bin.buffer);
  const d=await b.decrypt(e.hdr,e.ciphertext);
  assertT(Buffer.from(d).equals(Buffer.from(bin)),'bin eq');
});

console.log(`\n${"=".repeat(40)}`);
console.log(`Results: ${passed} passed, ${failed} failed`);
console.log(`${"=".repeat(40)}`);
process.exit(failed > 0 ? 1 : 0);
}

runTests().catch(e => { console.error(e); process.exit(1); });
