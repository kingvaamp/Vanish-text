/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Signal Double Ratchet Implementation — Production Grade (JavaScript)
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * A complete, spec-compliant implementation of the Signal Double Ratchet
 * algorithm using only the Web Crypto API (crypto.subtle).
 *
 * Specification: https://signal.org/docs/specifications/doubleratchet/
 *
 * This is the JavaScript build output — use directly in browsers or Node
 * without TypeScript compilation.
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 */

// ═════════════════════════════════════════════════════════════════════════════
//  CONSTANTS
// ═════════════════════════════════════════════════════════════════════════════

const ALG_AES = 'AES-GCM';
const ALG_ECDH = { name: 'ECDH', namedCurve: 'P-256' };
const HKDF_HASH = 'SHA-256';
const AES_KEY_BITS = 256;
const AES_IV_BYTES = 12;
const AES_TAG_BITS = 128;
const DH_BITS = 256;
const RK_BYTES = 32;
const CK_BYTES = 32;
const MK_BYTES = 32;

const DEFAULT_MAX_SKIP = 1000;
const DEFAULT_MAX_KEEP = 1000;
const DEFAULT_ROTATION_PERIOD = 500; // messages

// ═════════════════════════════════════════════════════════════════════════════
//  UTILITY HELPERS
// ═════════════════════════════════════════════════════════════════════════════

const ENCODER = new TextEncoder();
const DECODER = new TextDecoder();

/** Secure random bytes via Web Crypto */
function randomBytes(n) {
  return crypto.getRandomValues(new Uint8Array(n));
}

/** ArrayBuffer → base64 */
function b64encode(buf) {
  const bytes = new Uint8Array(buf);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/** base64 → Uint8Array */
function b64decode(str) {
  const binary = atob(str);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/** Concatenate multiple ArrayBuffers */
function concat(...bufs) {
  const total = bufs.reduce((s, b) => s + b.byteLength, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const b of bufs) {
    out.set(new Uint8Array(b), offset);
    offset += b.byteLength;
  }
  return out;
}

/** Compare two Uint8Arrays in constant time */
function constantTimeEq(a, b) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
  return d === 0;
}

/** Zero-fill a Uint8Array (best-effort memory wipe) */
function zeroize(buf) {
  if (!buf) return;
  buf.fill(0);
}

// ═════════════════════════════════════════════════════════════════════════════
//  CRYPTO PRIMITIVES (Web Crypto API only)
// ═════════════════════════════════════════════════════════════════════════════

/** Generate a new ECDH P-256 key pair */
async function generateDH() {
  return crypto.subtle.generateKey(ALG_ECDH, true, ['deriveBits']);
}

/** ECDH shared secret derivation (raw bits) */
async function dh(privateKey, publicKey) {
  return crypto.subtle.deriveBits({ name: 'ECDH', public: publicKey }, privateKey, DH_BITS);
}

/**
 * HKDF extract-then-derive.
 */
async function hkdf(salt, ikm, info, length) {
  const actualSalt = salt || new Uint8Array(32).buffer;
  const key = await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']);
  return crypto.subtle.deriveBits(
    { name: 'HKDF', hash: HKDF_HASH, salt: actualSalt, info: ENCODER.encode(info) },
    key,
    length * 8
  );
}

/**
 * KDF_RK — Root Key KDF (Signal spec §3.1).
 *
 * KDF_RK(rk, dh_out) = HKDF-SHA-256(salt=rk, ikm=dh_out, info="DoubleRatchetKeys")
 * Returns [root_key (32 bytes), chain_key (32 bytes)]
 */
async function kdfRK(rk, dhOut) {
  const out = await hkdf(rk, dhOut, 'DoubleRatchetKeys', RK_BYTES + CK_BYTES);
  const rootKey = out.slice(0, RK_BYTES);
  const chainKey = out.slice(RK_BYTES, RK_BYTES + CK_BYTES);
  return [rootKey, chainKey];
}

/**
 * KDF_CK — Chain Key KDF (Signal spec §3.1).
 *
 * KDF_CK(ck) = HMAC-SHA-256(ck, 0x01) || HMAC-SHA-256(ck, 0x02)
 * Returns [chain_key (32 bytes), message_key (32 bytes)]
 *
 * We derive both from a single HKDF call for efficiency.
 */
async function kdfCK(ck) {
  const out = await hkdf(null, ck, 'DoubleRatchetChainKeys', CK_BYTES + MK_BYTES);
  const chainKey = out.slice(0, CK_BYTES);
  const messageKey = out.slice(CK_BYTES, CK_BYTES + MK_BYTES);
  return [chainKey, messageKey];
}

/** AES-256-GCM encryption */
async function encryptAesGcm(key, plaintext, associatedData) {
  const iv = randomBytes(AES_IV_BYTES);
  const cryptoKey = await crypto.subtle.importKey('raw', key, ALG_AES, false, ['encrypt']);
  const ciphertext = await crypto.subtle.encrypt(
    { name: ALG_AES, iv, tagLength: AES_TAG_BITS, additionalData: associatedData },
    cryptoKey,
    plaintext
  );
  return { iv, ciphertext };
}

/** AES-256-GCM decryption */
async function decryptAesGcm(key, iv, ciphertext, associatedData) {
  const cryptoKey = await crypto.subtle.importKey('raw', key, ALG_AES, false, ['decrypt']);
  return crypto.subtle.decrypt(
    { name: ALG_AES, iv, tagLength: AES_TAG_BITS, additionalData: associatedData },
    cryptoKey,
    ciphertext
  );
}

// ═════════════════════════════════════════════════════════════════════════════
//  HEADER ENCODING / DECODING
// ═════════════════════════════════════════════════════════════════════════════

/**
 * Encode header to ArrayBuffer for AD.
 * Format: dhPub(65 bytes raw P-256) | Ns(4 BE) | PN(4 BE)
 */
function headerToBytes(h) {
  const dhPub = b64decode(h.dh);
  const buf = new Uint8Array(dhPub.length + 8);
  buf.set(dhPub, 0);
  const view = new DataView(buf.buffer, dhPub.length, 8);
  view.setUint32(0, h.n, false);
  view.setUint32(4, h.pn, false);
  return buf;
}

/** Extract dh, n, pn from serialized header bytes */
function bytesToHeader(buf, dhPubLen = 65) {
  const dh = b64encode(buf.slice(0, dhPubLen));
  const view = new DataView(buf.buffer, buf.byteOffset + dhPubLen, 8);
  const n = view.getUint32(0, false);
  const pn = view.getUint32(4, false);
  return { dh, n, pn };
}

// ═════════════════════════════════════════════════════════════════════════════
//  INDEXEDDB PERSISTENCE (Encrypted State)
// ═════════════════════════════════════════════════════════════════════════════

class DRStore {
  constructor(dbName, passphrase) {
    this.dbName = dbName;
    this.passphrase = passphrase;
    this.db = null;
  }

  async open() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(this.dbName, 1);
      req.onerror = () => reject(req.error);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('sessions')) {
          db.createObjectStore('sessions', { keyPath: 'sessionId' });
        }
      };
      req.onsuccess = () => {
        this.db = req.result;
        resolve();
      };
    });
  }

  async derivePassKey(salt) {
    if (!this.passphrase) throw new Error('Passphrase required for encrypted persistence');
    const base = await crypto.subtle.importKey('raw', ENCODER.encode(this.passphrase), 'PBKDF2', false, ['deriveBits']);
    return crypto.subtle.deriveBits(
      { name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 100000 },
      base,
      AES_KEY_BITS
    );
  }

  async encryptState(state) {
    if (!this.passphrase) {
      return { salt: '', iv: '', ciphertext: b64encode(ENCODER.encode(JSON.stringify(state))) };
    }
    const salt = randomBytes(16);
    const key = await this.derivePassKey(salt);
    const iv = randomBytes(AES_IV_BYTES);
    const cryptoKey = await crypto.subtle.importKey('raw', key, ALG_AES, false, ['encrypt']);
    const plaintext = ENCODER.encode(JSON.stringify(state));
    const ct = await crypto.subtle.encrypt(
      { name: ALG_AES, iv, tagLength: AES_TAG_BITS },
      cryptoKey,
      plaintext
    );
    zeroize(new Uint8Array(key));
    return { salt: b64encode(salt), iv: b64encode(iv), ciphertext: b64encode(ct) };
  }

  async decryptState(wrapped) {
    if (!this.passphrase) {
      const json = DECODER.decode(b64decode(wrapped.ciphertext));
      return JSON.parse(json);
    }
    const salt = b64decode(wrapped.salt);
    const iv = b64decode(wrapped.iv);
    const key = await this.derivePassKey(salt);
    const cryptoKey = await crypto.subtle.importKey('raw', key, ALG_AES, false, ['decrypt']);
    const pt = await crypto.subtle.decrypt(
      { name: ALG_AES, iv, tagLength: AES_TAG_BITS },
      cryptoKey,
      b64decode(wrapped.ciphertext)
    );
    zeroize(new Uint8Array(key));
    return JSON.parse(DECODER.decode(pt));
  }

  async save(sessionId, state) {
    if (!this.db) await this.open();
    const encrypted = await this.encryptState(state);
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('sessions', 'readwrite');
      const store = tx.objectStore('sessions');
      const req = store.put({ sessionId, ...encrypted, savedAt: Date.now() });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async load(sessionId) {
    if (!this.db) await this.open();
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('sessions', 'readonly');
      const store = tx.objectStore('sessions');
      const req = store.get(sessionId);
      req.onsuccess = async () => {
        if (!req.result) return resolve(null);
        try {
          const state = await this.decryptState(req.result);
          resolve(state);
        } catch (e) {
          reject(e);
        }
      };
      req.onerror = () => reject(req.error);
    });
  }

  async delete(sessionId) {
    if (!this.db) await this.open();
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('sessions', 'readwrite');
      const store = tx.objectStore('sessions');
      const req = store.delete(sessionId);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async wipe() {
    if (!this.db) await this.open();
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('sessions', 'readwrite');
      const store = tx.objectStore('sessions');
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  close() {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// ═════════════════════════════════════════════════════════════════════════════
//  MAIN DOUBLE RATCHET CLASS
// ═════════════════════════════════════════════════════════════════════════════

/**
 * Signal Double Ratchet session.
 *
 * Maintains all official state variables and provides encrypt/decrypt
 * operations with automatic ratcheting, out-of-order message handling,
 * and optional encrypted persistence.
 */
class DoubleRatchet {
  /**
   * @param {Object} options
   * @param {number} [options.maxSkip=1000] - Max skipped messages
   * @param {number} [options.maxKeep=1000] - Max stored skipped keys
   * @param {number} [options.rotationPeriod=500] - Messages between RK rotations
   * @param {string} [options.dbName='VanishDR'] - IndexedDB database name
   * @param {string} [options.sessionId] - Session ID for persistence
   * @param {string} [options.passphrase] - Passphrase for encrypted storage
   */
  constructor(options = {}) {
    // Core State (Signal spec §3.2)
    this.RK = null;
    this.CKs = null;
    this.CKr = null;
    this.DHs = null;
    this.DHr = null;
    this.Ns = 0;
    this.Nr = 0;
    this.PN = 0;
    this.MKSKIPPED = new Map();

    // Extended Security State
    this.sessionCounter = 0;
    this.lastDecryptTime = 0;
    this.messagesSinceRotation = 0;

    // Configuration
    this.maxSkip = options.maxSkip ?? DEFAULT_MAX_SKIP;
    this.maxKeep = options.maxKeep ?? DEFAULT_MAX_KEEP;
    this.rotationPeriod = options.rotationPeriod ?? DEFAULT_ROTATION_PERIOD;
    this.dbName = options.dbName ?? 'VanishDR';
    this.sessionId = options.sessionId;
    this.passphrase = options.passphrase;

    this.DHrRaw = null;
    this.initialized = false;
    this.store = null;
    this.destroyed = false;
  }

  // ── Internal Helpers ──────────────────────────────────────────

  assertReady() {
    if (this.destroyed) throw new Error('DoubleRatchet session has been destroyed');
    if (!this.initialized) throw new Error('DoubleRatchet not initialized. Call initAlice() or initBob() first.');
  }

  async getStore() {
    if (!this.store) {
      this.store = new DRStore(this.dbName, this.passphrase);
      await this.store.open();
    }
    return this.store;
  }

  /**
   * Skip message keys between current Nr and target.
   * Stores skipped keys in MKSKIPPED for out-of-order handling.
   */
  async SkipMessageKeys(until) {
    if (!this.CKr) return;
    if (this.Nr >= until) return;

    if (until - this.Nr > this.maxSkip) {
      throw new Error(`Skip limit exceeded: would skip ${until - this.Nr} messages (max=${this.maxSkip})`);
    }

    if (this.MKSKIPPED.size >= this.maxKeep) {
      this.pruneSkippedKeys();
    }

    while (this.Nr < until) {
      const [newCKr, mk] = await kdfCK(this.CKr);
      zeroize(new Uint8Array(this.CKr));
      this.CKr = newCKr;
      const key = `${this.DHrRaw}|${this.Nr}`;
      this.MKSKIPPED.set(key, mk);
      this.Nr++;
    }
  }

  /**
   * Try to decrypt using stored skipped message keys.
   */
  async TrySkippedMessageKeys(header, ciphertext, ad) {
    const key = `${header.dh}|${header.n}`;
    const mk = this.MKSKIPPED.get(key);
    if (!mk) return null;

    try {
      const ctBuf = b64decode(ciphertext);
      const iv = ctBuf.slice(0, AES_IV_BYTES);
      const ct = ctBuf.slice(AES_IV_BYTES);
      const plaintext = await decryptAesGcm(mk, iv, ct, ad);
      zeroize(new Uint8Array(mk));
      this.MKSKIPPED.delete(key);
      return plaintext;
    } catch {
      return null;
    }
  }

  /**
   * Perform a DH ratchet step.
   *
   * Signal spec §3.5, step 6:
   *   1. SkipMessageKeys(header.pn)
   *   2. If header.dh != DHr:
   *      - RK, CKr = KDF_RK(RK, DH(DHs.priv, DHr))
   *      - DHs = GENERATE_DH()
   *      - RK, CKs = KDF_RK(RK, DH(DHs.priv, DHr))
   */
  async DHRatchet(header) {
    await this.SkipMessageKeys(header.pn);

    const dhPub = await importDHPublicKey(b64decode(header.dh));
    this.PN = this.Ns;
    this.Ns = 0;
    this.Nr = 0;

    this.DHr = dhPub;
    this.DHrRaw = header.dh;

    if (!this.DHs || !this.RK) throw new Error('Invalid state for DHRatchet');

    // RK, CKr = KDF_RK(RK, DH(DHs.private, DHr))
    const dhOut1 = await dh(this.DHs.privateKey, this.DHr);
    const [rk1, ckr] = await kdfRK(this.RK, dhOut1);
    zeroize(new Uint8Array(this.RK));
    if (this.CKr) zeroize(new Uint8Array(this.CKr));
    this.RK = rk1;
    this.CKr = ckr;

    // Generate new sending key pair
    const newDHs = await generateDH();
    this.DHs = newDHs;

    // RK, CKs = KDF_RK(RK, DH(newDHs.private, DHr))
    const dhOut2 = await dh(newDHs.privateKey, this.DHr);
    const [rk2, cks] = await kdfRK(this.RK, dhOut2);
    zeroize(new Uint8Array(this.RK));
    if (this.CKs) zeroize(new Uint8Array(this.CKs));
    this.RK = rk2;
    this.CKs = cks;
  }

  /**
   * Periodic root key rotation for forward secrecy.
   */
  async maybeRotateRootKey() {
    if (this.messagesSinceRotation < this.rotationPeriod) return;
    if (!this.DHs || !this.DHr || !this.RK) return;

    const newDHs = await generateDH();
    const dhOut = await dh(newDHs.privateKey, this.DHr);
    const [rk, cks] = await kdfRK(this.RK, dhOut);
    zeroize(new Uint8Array(this.RK));
    this.RK = rk;

    if (this.CKs) zeroize(new Uint8Array(this.CKs));
    this.CKs = cks;
    this.DHs = newDHs;
    this.messagesSinceRotation = 0;
  }

  pruneSkippedKeys() {
    const excess = this.MKSKIPPED.size - this.maxKeep + Math.floor(this.maxKeep * 0.1);
    const entries = Array.from(this.MKSKIPPED.entries());
    for (let i = 0; i < excess && i < entries.length; i++) {
      zeroize(new Uint8Array(entries[i][1]));
      this.MKSKIPPED.delete(entries[i][0]);
    }
  }

  async serializeState() {
    const exportPubRaw = async (kp) => {
      const raw = await crypto.subtle.exportKey('raw', kp.publicKey);
      return b64encode(raw);
    };
    const exportPrivJwk = async (kp) => {
      return crypto.subtle.exportKey('jwk', kp.privateKey);
    };
    const exportPubFromCryptoKey = async (ck) => {
      const raw = await crypto.subtle.exportKey('raw', ck);
      return b64encode(raw);
    };

    const skipped = {};
    for (const [k, v] of this.MKSKIPPED) {
      skipped[k] = b64encode(v);
    }

    return {
      RK: this.RK ? b64encode(this.RK) : '',
      CKs: this.CKs ? b64encode(this.CKs) : null,
      CKr: this.CKr ? b64encode(this.CKr) : null,
      DHs: this.DHs ? {
        privateJwk: await exportPrivJwk(this.DHs),
        publicRaw: await exportPubRaw(this.DHs),
      } : null,
      DHr: this.DHr ? await exportPubFromCryptoKey(this.DHr) : null,
      Ns: this.Ns,
      Nr: this.Nr,
      PN: this.PN,
      MKSKIPPED: skipped,
      sessionCounter: this.sessionCounter,
      lastDecryptTime: this.lastDecryptTime,
      messagesSinceRotation: this.messagesSinceRotation,
    };
  }

  async deserializeState(state) {
    this.RK = state.RK ? b64decode(state.RK).buffer : null;
    this.CKs = state.CKs ? b64decode(state.CKs).buffer : null;
    this.CKr = state.CKr ? b64decode(state.CKr).buffer : null;

    if (state.DHs) {
      const privKey = await crypto.subtle.importKey(
        'jwk', state.DHs.privateJwk, ALG_ECDH, true, ['deriveBits']
      );
      const pubKey = await crypto.subtle.importKey(
        'raw', b64decode(state.DHs.publicRaw), ALG_ECDH, true, []
      );
      this.DHs = { privateKey: privKey, publicKey: pubKey };
    } else {
      this.DHs = null;
    }

    if (state.DHr) {
      this.DHr = await crypto.subtle.importKey(
        'raw', b64decode(state.DHr), ALG_ECDH, true, []
      );
      this.DHrRaw = state.DHr;
    } else {
      this.DHr = null;
      this.DHrRaw = null;
    }

    this.Ns = state.Ns;
    this.Nr = state.Nr;
    this.PN = state.PN;

    this.MKSKIPPED = new Map();
    for (const [k, v] of Object.entries(state.MKSKIPPED)) {
      this.MKSKIPPED.set(k, b64decode(v).buffer);
    }

    this.sessionCounter = state.sessionCounter;
    this.lastDecryptTime = state.lastDecryptTime;
    this.messagesSinceRotation = state.messagesSinceRotation;
    this.initialized = true;
  }

  normalizeAD(ad) {
    if (!ad) return new ArrayBuffer(0);
    return typeof ad === 'string' ? ENCODER.encode(ad) : ad;
  }

  // ═══════════════════════════════════════════════════════════════
  //  PUBLIC API
  // ═══════════════════════════════════════════════════════════════

  /**
   * Initialize as Alice (the party that sends the first message).
   *
   * @param {string} rootKey    Shared secret from X3DH, 32 bytes base64
   * @param {string} bobPubKey  Bob's public DH key, base64 raw P-256
   */
  async initAlice(rootKey, bobPubKey) {
    this.RK = b64decode(rootKey).slice(0, RK_BYTES).buffer;
    const dhPub = await importDHPublicKey(b64decode(bobPubKey));
    this.DHr = dhPub;
    this.DHrRaw = bobPubKey;
    this.DHs = await generateDH();
    this.CKs = null;
    this.CKr = null;
    this.Ns = 0;
    this.Nr = 0;
    this.PN = 0;
    this.MKSKIPPED = new Map();
    this.sessionCounter = 0;
    this.messagesSinceRotation = 0;
    this.lastDecryptTime = 0;
    this.initialized = true;
    this.destroyed = false;
  }

  /**
   * Initialize as Bob (the party that receives the first message).
   *
   * @param {string} rootKey       Shared secret from X3DH, 32 bytes base64
   * @param {CryptoKeyPair} bobKeyPair  Bob's DH key pair from X3DH
   */
  async initBob(rootKey, bobKeyPair) {
    this.RK = b64decode(rootKey).slice(0, RK_BYTES).buffer;
    this.DHs = bobKeyPair;
    this.DHr = null;
    this.DHrRaw = null;
    this.CKs = null;
    this.CKr = null;
    this.Ns = 0;
    this.Nr = 0;
    this.PN = 0;
    this.MKSKIPPED = new Map();
    this.sessionCounter = 0;
    this.messagesSinceRotation = 0;
    this.lastDecryptTime = 0;
    this.initialized = true;
    this.destroyed = false;
  }

  /**
   * Encrypt plaintext, returning { header, ciphertext }.
   *
   * @param {string|ArrayBuffer} plaintext       Message to encrypt
   * @param {ArrayBuffer|string} [associatedData]  Optional associated data
   * @returns {Promise<{header: DRHeader, ciphertext: string}>}
   */
  async encrypt(plaintext, associatedData) {
    this.assertReady();
    if (!this.DHs) throw new Error('No DH key pair available');

    const ad = this.normalizeAD(associatedData);

    // 1. Initialize sending chain if needed (first encrypt as Alice)
    if (!this.CKs && this.DHr && this.RK) {
      const dhOut = await dh(this.DHs.privateKey, this.DHr);
      const [rk, cks] = await kdfRK(this.RK, dhOut);
      zeroize(new Uint8Array(this.RK));
      this.RK = rk;
      this.CKs = cks;
    }

    if (!this.CKs) throw new Error('Cannot encrypt: chain key not initialized');

    // 2. Step chain key forward
    const [newCKs, mk] = await kdfCK(this.CKs);
    zeroize(new Uint8Array(this.CKs));
    this.CKs = newCKs;

    // Periodic root key rotation
    this.messagesSinceRotation++;
    await this.maybeRotateRootKey();

    // 3. Build header
    const pubRaw = await crypto.subtle.exportKey('raw', this.DHs.publicKey);
    const header = {
      dh: b64encode(pubRaw),
      n: this.Ns,
      pn: this.PN,
    };
    this.Ns++;

    // 4. Encrypt
    const headerBytes = headerToBytes(header);
    const fullAD = concat(ad, headerBytes);
    const pt = typeof plaintext === 'string' ? ENCODER.encode(plaintext) : plaintext;
    const { iv, ciphertext: ct } = await encryptAesGcm(mk, pt, fullAD);
    zeroize(new Uint8Array(mk));

    const combined = concat(iv, ct);
    const ciphertextB64 = b64encode(combined);

    await this.save();

    return { header, ciphertext: ciphertextB64 };
  }

  /**
   * Decrypt a message, handling out-of-order delivery.
   *
   * @param {DRHeader} header          Message header
   * @param {string} ciphertext        Base64-encoded ciphertext (iv || ct)
   * @param {ArrayBuffer|string} [associatedData]  Optional associated data
   * @returns {Promise<Uint8Array>}    Decrypted plaintext
   */
  async decrypt(header, ciphertext, associatedData) {
    this.assertReady();

    const ad = this.normalizeAD(associatedData);
    const headerBytes = headerToBytes(header);
    const fullAD = concat(ad, headerBytes);

    // Anti-replay time window check
    const now = Date.now();
    if (this.lastDecryptTime > 0 && now - this.lastDecryptTime > 7 * 24 * 60 * 60 * 1000) {
      throw new Error('Session stale: no decrypt activity for > 7 days');
    }
    this.sessionCounter++;

    // 1. Try skipped message keys
    const skipped = await this.TrySkippedMessageKeys(header, ciphertext, fullAD);
    if (skipped) {
      this.lastDecryptTime = now;
      await this.save();
      return new Uint8Array(skipped);
    }

    // 2. DH Ratchet check
    const dhPub = await importDHPublicKey(b64decode(header.dh));
    if (!this.DHr || !(await equalCryptoKeys(this.DHr, dhPub))) {
      await this.DHRatchet(header);
    }

    // 3. Skip message keys up to header.n
    await this.SkipMessageKeys(header.n);

    // 4. Step receiving chain
    if (!this.CKr) throw new Error('Cannot decrypt: no receiving chain key');
    const [newCKr, mk] = await kdfCK(this.CKr);
    zeroize(new Uint8Array(this.CKr));
    this.CKr = newCKr;
    this.Nr++;

    // 5. Decrypt
    const ctBuf = b64decode(ciphertext);
    const iv = ctBuf.slice(0, AES_IV_BYTES);
    const ct = ctBuf.slice(AES_IV_BYTES);

    let plaintext;
    try {
      plaintext = await decryptAesGcm(mk, iv, ct, fullAD);
    } catch (e) {
      zeroize(new Uint8Array(mk));
      throw new Error(`Decryption failed: ${e.message || 'auth tag mismatch'}`);
    }
    zeroize(new Uint8Array(mk));

    this.lastDecryptTime = now;
    await this.save();

    return new Uint8Array(plaintext);
  }

  /** Convenience: decrypt then decode as UTF-8 string */
  async decryptString(header, ciphertext, associatedData) {
    const bytes = await this.decrypt(header, ciphertext, associatedData);
    return DECODER.decode(bytes);
  }

  // ── Persistence ────────────────────────────────────────────────

  async save() {
    if (!this.sessionId) return;
    const store = await this.getStore();
    const state = await this.serializeState();
    await store.save(this.sessionId, state);
  }

  async load() {
    if (!this.sessionId) return false;
    const store = await this.getStore();
    const state = await store.load(this.sessionId);
    if (!state) return false;
    await this.deserializeState(state);
    return true;
  }

  async deleteSession() {
    if (!this.sessionId) return;
    const store = await this.getStore();
    await store.delete(this.sessionId);
  }

  // ── Lifecycle ──────────────────────────────────────────────────

  destroy() {
    if (this.RK) zeroize(new Uint8Array(this.RK));
    if (this.CKs) zeroize(new Uint8Array(this.CKs));
    if (this.CKr) zeroize(new Uint8Array(this.CKr));
    for (const [, mk] of this.MKSKIPPED) zeroize(new Uint8Array(mk));

    this.RK = null;
    this.CKs = null;
    this.CKr = null;
    this.DHs = null;
    this.DHr = null;
    this.DHrRaw = null;
    this.MKSKIPPED = new Map();
    this.initialized = false;
    this.destroyed = true;

    if (this.store) {
      this.store.close();
      this.store = null;
    }
  }

  async getDHPublicKey() {
    if (!this.DHs) throw new Error('No DH key pair');
    const raw = await crypto.subtle.exportKey('raw', this.DHs.publicKey);
    return b64encode(raw);
  }

  isReady() {
    return this.initialized && !this.destroyed;
  }

  getStats() {
    return {
      ns: this.Ns,
      nr: this.Nr,
      pn: this.PN,
      skippedCount: this.MKSKIPPED.size,
      messagesSinceRotation: this.messagesSinceRotation,
    };
  }
}

// ═════════════════════════════════════════════════════════════════════════════
//  STANDALONE UTILITY FUNCTIONS
// ═════════════════════════════════════════════════════════════════════════════

async function importDHPublicKey(rawBytes) {
  return crypto.subtle.importKey('raw', rawBytes, ALG_ECDH, true, []);
}

async function equalCryptoKeys(a, b) {
  const rawA = await crypto.subtle.exportKey('raw', a);
  const rawB = await crypto.subtle.exportKey('raw', b);
  return constantTimeEq(new Uint8Array(rawA), new Uint8Array(rawB));
}

/** Generate an ephemeral ECDH P-256 key pair */
async function generateEphemeralKeyPair() {
  return generateDH();
}

/** Export a public key to base64 raw format */
async function exportPublicKeyRawB64(publicKey) {
  const raw = await crypto.subtle.exportKey('raw', publicKey);
  return b64encode(raw);
}

/** Import a private key from JWK format */
async function importPrivateKeyJwk(jwk) {
  return crypto.subtle.importKey('jwk', jwk, ALG_ECDH, true, ['deriveBits']);
}

/**
 * Derive a root key from an initial shared secret using HKDF.
 * Use this after X3DH to get the 32-byte root key for initAlice/Bob.
 */
async function deriveInitialRootKey(sharedSecret, salt) {
  return hkdf(salt || null, sharedSecret, 'VanishDoubleRatchetRootKey', RK_BYTES);
}

/**
 * Safety number computation (Signal-style 60-digit verification).
 */
async function computeSafetyNumber(myPublicB64, theirPublicB64) {
  if (!myPublicB64 || !theirPublicB64) throw new Error('Both public keys required');
  const sorted = [myPublicB64, theirPublicB64].sort();
  const enc = new TextEncoder();
  const hash = await crypto.subtle.digest('SHA-256', enc.encode(sorted.join('||VanishText||')));
  const bytes = new Uint8Array(hash).slice(0, 20);
  let decimal = '';
  for (const byte of bytes) decimal += byte.toString().padStart(3, '0');
  return decimal.slice(0, 60).match(/.{1,5}/g).join(' ');
}

// ═════════════════════════════════════════════════════════════════════════════
//  EXPORTS
// ═════════════════════════════════════════════════════════════════════════════

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    DoubleRatchet,
    generateEphemeralKeyPair,
    exportPublicKeyRawB64,
    importPrivateKeyJwk,
    deriveInitialRootKey,
    computeSafetyNumber,
  };
}
